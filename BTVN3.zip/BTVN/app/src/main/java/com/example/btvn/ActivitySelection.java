package com.example.btvn;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;

public class ActivitySelection extends Activity {

    private RadioGroup radioGroup;
    private Button btnStart;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        radioGroup = findViewById(R.id.radioGroup);
        btnStart = findViewById(R.id.btnStart);

        // Bắt đầu: Disable nút và để màu xám
        btnStart.setEnabled(false);
        btnStart.setBackgroundResource(R.drawable.rounded_button_disabled);


        // Khi chọn radio nào đó thì enable nút và đổi màu
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId != -1) {
                btnStart.setEnabled(true);
                btnStart.setBackgroundResource(R.drawable.rounded_button); // bo tròn màu tím

            }
        });

        // Bấm nút start để chuyển qua Activity Game
        btnStart.setOnClickListener(v -> {
            int checkedId = radioGroup.getCheckedRadioButtonId();
            if (checkedId != -1) {
                int digitCount = 0;
                if (checkedId == R.id.radio2) {
                    digitCount = 2;
                } else if (checkedId == R.id.radio3) {
                    digitCount = 3;
                } else if (checkedId == R.id.radio4) {
                    digitCount = 4;
                }

                Intent intent = new Intent(ActivitySelection.this, GameActivity.class);
                intent.putExtra("digitCount", digitCount);  // gửi số chữ số
                startActivity(intent);
            }
        });
    }
}
