package com.example.btvn;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class GameActivity extends AppCompatActivity {

    private int targetNumber;
    private int attemptsLeft = 10;
    private final StringBuilder guessHistory = new StringBuilder();

    private TextView txtLastGuess, txtAttempts, txtHint;
    private EditText editGuess;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        txtLastGuess = findViewById(R.id.txtLastGuess);
        txtAttempts = findViewById(R.id.txtAttempts);
        txtHint = findViewById(R.id.txtHint);
        editGuess = findViewById(R.id.editGuess);
        Button btnConfirm = findViewById(R.id.btnConfirm);

        Intent intent = getIntent();
        int digitCount = intent.getIntExtra("digitCount", 0);

        if (digitCount > 0) {
            targetNumber = generateRandomNumber(digitCount);
        } else {
            Toast.makeText(this, "Không nhận được dữ liệu chữ số!", Toast.LENGTH_LONG).show();
            finish();
        }

        btnConfirm.setOnClickListener(v -> {
            String guessStr = editGuess.getText().toString().trim();
            if (guessStr.isEmpty()) {
                editGuess.setError("Bạn cần nhập một số!");
                return;
            }

            int guess;
            try {
                guess = Integer.parseInt(guessStr);
            } catch (NumberFormatException e) {
                editGuess.setError("Chỉ được nhập số!");
                return;
            }

            // Cập nhật lịch sử đoán
            if (guessHistory.length() > 0) {
                guessHistory.append(", ");
            }
            guessHistory.append(guess);

            txtLastGuess.setText("Your last guess: " + guessHistory);
            attemptsLeft--;
            txtAttempts.setText("Remaining attempts: " + attemptsLeft);

            if (guess == targetNumber) {
                showDialogWin();
            } else if (attemptsLeft == 0) {
                showDialogGameOver();
            } else {
                txtHint.setText(guess > targetNumber ? "Try a smaller number" : "Try a bigger number");
            }

            editGuess.setText("");
        });
    }

    private int generateRandomNumber(int digits) {
        int min = (int) Math.pow(10, digits - 1);
        int max = (int) Math.pow(10, digits) - 1;
        return new Random().nextInt(max - min + 1) + min;
    }

    @SuppressLint("SetTextI18n")
    private void showDialogWin() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_game_congratulation, null);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)
                .create();

        Button btnYes = dialogView.findViewById(R.id.btnYes);
        Button btnNo = dialogView.findViewById(R.id.btnNo);
        TextView txtMessage = dialogView.findViewById(R.id.txtMessage);
        txtMessage.setText("Congratulations!\n\nYou guessed the number " + targetNumber + " correctly!\n\nPlay again?");

        btnYes.setOnClickListener(v -> {
            dialog.dismiss();
            finish(); // quay lại chọn lại số chữ số
        });

        btnNo.setOnClickListener(v -> {
            dialog.dismiss();
            finishAffinity(); // thoát app
        });

        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
        }
    }

    @SuppressLint("SetTextI18n")
    private void showDialogGameOver() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_game_over, null);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)
                .create();

        Button btnYes = dialogView.findViewById(R.id.btnYes);
        Button btnNo = dialogView.findViewById(R.id.btnNo);
        TextView txtMessage = dialogView.findViewById(R.id.txtMessage);

        txtMessage.setText("You've used all your attempts.\n\nMy number was: " + targetNumber +
                "\nYour guesses: " + guessHistory + "\n\nWould you like to play again?");
        btnYes.setOnClickListener(v -> {
            dialog.dismiss();
            finish(); // quay lại chọn lại số chữ số
        });

        btnNo.setOnClickListener(v -> {
            dialog.dismiss();
            finishAffinity(); // thoát app
        });

        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
        }
    }
}
